---------- Voraussetzungen ------------------

Es wird eine installierten JDK Version 15 oder h�her f�r die Ausf�hrung der beiliegenden .jar-Datei empfohlen.
Die Ausf�hrung der aktuellen Version dieses Programms wurde nicht mit �lteren Versionen von JDK getestet.

---------- Beschreibung des Programms -------

Nach dem verschiedene Parameter vom Benutzer eingestellt wurden, wird mit einem Klick auf den "Start"-Knopf die Simulation gestartet.
Dabei wird der folgende Ablauf entsprechend der gew�nschten Anzahl an Versuchen wiederholt:
	1. Erstellung eines zuf�lligen Waldes mit Brandherden nach den Parametern
	2. Dann schrittweise:
		2a: Alle Feuer breiten sich (falls m�glich) um ein Feld in alle Richtungen aus
		2b: Es wird durch den Algorithmus ein einzelnes zu l�schendes Feld bestimmt,
			- daf�r wird f�r alle Waldst�cke bestimmt, zu wie vielen anderen Waldst�cken sie eine (direkte) Verbindung haben
			- Das Feuer mit der h�chsten Summe dieser Werte der direkt benachbarten Waldst�cke wird gel�scht
		2c: Schritte 2a und 2b wiederholen, bis sich kein Feuer mehr ausbreiten kann
	3. Ausgabe der Ergebnisse in Konsole und in .txt-Datei

---------- Erkl�rung der Darstellung --------

Gr�n = Baum
Schwarz = Brandschneise bzw. Leerfl�che
Rot = Feuer
Blau = gel�schtes Feuer

---------- Anmerkungen ----------------------

Diese �berarbeitete Version des beiliegenden Programms ist nicht f�r die kommerzielle Nutzung gedacht.
Die erste Version dieses Programms war urspr�nglich eine Abgabe f�r den Bundeswettbewerb der Informatik.