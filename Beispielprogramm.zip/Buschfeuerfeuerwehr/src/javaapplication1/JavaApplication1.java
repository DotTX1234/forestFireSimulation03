/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

/**
 *
 * @author user
 */
public class JavaApplication1 {

    /**
     * @param args the command line arguments
     */
    
    public static int[][] wald;
    
    public static int fires=4; //legt die Anzahl an Brandherden fest
    
    public static int seed = 50; //die Wahrscheinlichkeit das ein Feld Wald ist
    
    public static void main(String[] args) {
        // TODO code application logic here
        //int wald = new int[10][10];
        
        //wald = generateforest();
        
        BurningFrame.main(args);
        
    }
    
    public static int[][] generateforest(int width, int height){
        wald = new int[width][height];
        for(int c = 0;c<wald.length;c++){
            for(int d = 0; d<wald[c].length;d++){
                int randomNumber = (int) (Math.random() * 101);
                if(randomNumber < seed){
                    wald[c][d] = 0;
                }
                else if(seed < randomNumber){
                    wald[c][d] = 1;
                }
            }
        }  
        
        //int randomfire = (int) (Math.random() * 10);
        for(int n = 0;n<fires;n++){
            int randomX = (int) (Math.random() * wald.length);
            int randomY = (int) (Math.random() * wald[0].length);
            wald[randomX][randomY] = 2;
        }
        //wald[5][5] = 2;
        //wald[20][20] = 2;
        //wald[40][40] = 2;
        return wald;
    }
    
    public static void extingush(int[][] wald){
        //priority soll für alle Feuer die Priorität in diesem Zug enthalten
        int[][] priority = new int[wald.length][wald[0].length]; 
        
        //priority wird komplett mit 0 belegt
        for(int a = 0;a<priority.length;a++){
            for(int b = 0;b<priority[a].length;b++){
                priority[a][b] = 0;
            }
        }
        
        //von jedem Feld in wald das eine 1 enthält(ein Feuer ist) wird near 
        //ausgeführt
        for(int j = 0; j< wald.length;j++){
            for(int k = 0; k< wald[j].length; k++){
                if(wald[j][k] == 2){
                    priority[j][k] = near(3,wald,j,k);
                }
            }
        }
    }
    
    public static int near(int tiefe, int[][] wald, int positionX, int positionY){
        if(tiefe > 1){
            int neighbors = 0;
            
            if(wald[positionX].length > positionY +1){
                if(wald[positionX][positionY+1] == 0){
                    neighbors = neighbors + near2(tiefe-1, wald, positionX, positionY+1,0);
                }
            }
            
            if(wald.length > positionX +1){
                if(wald[positionX+1][positionY+1] == 0){
                    neighbors = neighbors + near2(tiefe-1, wald, positionX+1, positionY,1);
                }
            }
            
            if(0 < positionX -1 ){
                if(wald[positionX][positionY-1] == 0){
                    neighbors = neighbors + near2(tiefe-1, wald, positionX, positionY-1,2);
                }
            }
            
            if(0 < positionY -1){
                if(wald[positionX-1][positionY] == 0){
                    neighbors = neighbors + near2(tiefe-1, wald, positionX-1, positionY,3);
                }
            }
            return neighbors;
        }
        else{
            return 1;
        }
    }
    
    public static int near2(int tiefe, int[][] wald, int positionX, int positionY, int from){
        if(tiefe > 1){
            int neighbors = 0;
            
            if(wald[positionX].length > positionY +1 && from != 0){
                if(wald[positionX][positionY+1] == 0){
                    neighbors = neighbors + near(tiefe-1, wald, positionX, positionY+1);
                }
            }
            
            if(wald.length > positionX +1 && from != 1){
                if(wald[positionX+1][positionY+1] == 0){
                    neighbors = neighbors + near(tiefe-1, wald, positionX+1, positionY);
                }
            }
            
            if(0 < positionX -1  && from != 2){
                if(wald[positionX][positionY-1] == 0){
                    neighbors = neighbors + near(tiefe-1, wald, positionX, positionY-1);
                }
            }
            
            if(0 < positionY -1 && from != 3){
                if(wald[positionX-1][positionY] == 0){
                    neighbors = neighbors + near(tiefe-1, wald, positionX-1, positionY);
                }
            }
            return neighbors;
        }
        else{
            return 1;
        }
    }

    public static int[][] getWald() {
        return wald;
    }

    public static int getFires() {
        return fires;
    }
    
    public static int getSeed(){
        return seed;
    }

    public static void setSeed(int seed) {
        JavaApplication1.seed = seed;
    }

    public static void setFires(int fires) {
        JavaApplication1.fires = fires;
    }
    
    
    
}